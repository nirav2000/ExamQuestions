# Command Word Coach JSON Pack

This pack is organised for the ExamQuestions / Command Word Coach app.

## Files

- `command-explainers.json` — one explainer object per command word.
- `manifest.json` — list of command sets and paths.
- `all-command-word-questions.json` — all questions combined into one uploadable array.
- `command-sets/*.json` — one file per command word, with 10 questions each.

## Why separate files are useful

Separate files are easier to maintain, expand and load by command word. For the current app, `all-command-word-questions.json`
can be uploaded directly because the app expects an array of question objects.

## App change suggested

Load `command-explainers.json` into the existing `commandExplainers` object, and load a command-specific question file
such as `command-sets/why.json` when a learner chooses a command word.
